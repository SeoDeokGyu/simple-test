# 실습
# hello 을 화면에 표시

# 1. 방법
print("hello")

# 2. 방법
a="hello"
print(a)
