# 실습
# https://www.saucedemo.com/ 접속 및 로그인후 나오는 첫페이지에서
# 상품설명을 모두 크롤링해서 화면에 표시하는 코딩을 하세요.

import os, time, requests
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager

driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=Options())
driver.get("https://www.saucedemo.com/")

driver.find_element(By.CSS_SELECTOR, "#user-name").send_keys("standard_user")
driver.find_element(By.CSS_SELECTOR, "#password").send_keys("secret_sauce")
driver.find_element(By.CSS_SELECTOR, "input[type='submit']").click()

time.sleep(1)

os.makedirs("../img/", exist_ok=True)

t = driver.find_elements(By.CSS_SELECTOR, ".inventory_item")
for idx, item in enumerate(t, 1):
    name = item.find_element(By.CSS_SELECTOR, ".inventory_item_name").text
    desc = item.find_element(By.CSS_SELECTOR, ".inventory_item_desc").text
    price = item.find_element(By.CSS_SELECTOR, ".inventory_item_price").text
    img_url = item.find_element(By.CSS_SELECTOR, ".inventory_item_img").get_attribute("src")
    print(f"{idx}. {name} | {price}\n | {desc}\n | img: {img_url}\n")

    if img_url:
        img_name = os.path.basename(img_url)
        with open(f"../img/{name}", "wb") as f:
            f.write(requests.get(img_url).content)

driver.quit()