package com.simplecoding.simpledms.emp.repository;

import com.simplecoding.simpledms.dept.entity.Dept;
import com.simplecoding.simpledms.emp.entity.Emp;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface EmpRepository extends JpaRepository<Emp, Long> {
//    퀴즈: 사원 like 검색 작성
    @Query(value = "select e from Emp e\n" +
            "where e.ename like %:searchKeyword%")
    Page<Emp> selectEmpList(@Param("searchKeyword") String searchKeyword,
                              Pageable pageable);
}
