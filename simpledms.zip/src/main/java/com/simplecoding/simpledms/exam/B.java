package com.simplecoding.simpledms.exam;

public class B {
//    2. 생성자 DI와 컨트롤러를 만들려고 합니다.
//    아래 코드 중 누락된 부분을 추가하세요
//
//    public class DeptController {
//        //        서비스 가져오기
//        private DeptService deptService;
//...
//    }

//    누락된 부분 2가지
//    @RequiredArgsConstructor
//    @Controller
}
