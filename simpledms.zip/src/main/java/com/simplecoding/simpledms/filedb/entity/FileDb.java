package com.simplecoding.simpledms.filedb.entity;

import com.simplecoding.simpledms.common.BaseTimeEntity;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "TB_FILE_DB")

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode(of = "uuid", callSuper = false)
public class FileDb extends BaseTimeEntity {

    @Id
    private String uuid;                    // 기본키, 자바 UUID 이용
    private String fileTitle;
    private String fileContent;
    @Lob                                      //  DB자료형이 BOLB 일경우 붙이는 어노테이션
    private byte[] fileData;              // 업로드 이미지(DB 저장)
    private String fileUrl;                  // 이미지 다운로드 URL(img태그에 사용)
}
