package com.simplecoding.simpledms.filedb.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class FileDbDto {
//    DTO 의 필드가 화면에 보임 : 결정)성능) 이미지는 빼기
//                                              왜? 화면에 필요한 것은 다운로드url만 있으면 됨, 이미지나옴
    private String uuid;                    // 기본키, 자바 UUID 이용
    private String fileTitle;
    private String fileContent;
    private String fileUrl;                  // 이미지 다운로드 URL(img태그에 사용)

//    TODO : 생성자(매개변수 2개)
    public FileDbDto(String fileTitle, String fileContent) {
        this.fileTitle = fileTitle;
        this.fileContent = fileContent;
    }
}
